/* Borrowed from Mutils.h from package Matrix */

#include <R.h>  /* includes Rconfig.h */
#include <Rdefines.h> /* Rinternals.h + GET_SLOT etc */

SEXP NEW_OBJECT_OF_CLASS(const char* cls);
